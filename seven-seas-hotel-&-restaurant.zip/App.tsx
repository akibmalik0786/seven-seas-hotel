
import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Menu from './components/Menu';
import Rooms from './components/Rooms';
import PartyHall from './components/PartyHall';
import Gallery from './components/Gallery';
import Contact from './components/Contact';
import Footer from './components/Footer';

function App() {
  return (
    <div className="bg-white min-h-screen">
      <Navbar />
      <main>
        <Hero />
        
        {/* Quick Info Section */}
        <div className="py-12 bg-indigo-50 border-y border-indigo-100">
          <div className="max-w-7xl mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { label: "Food Quality", value: "100% Vegetarian" },
              { label: "Accommodation", value: "Fully AC Rooms" },
              { label: "Celebrations", value: "Grand Party Hall" },
              { label: "Location", value: "Shahabad, UP" }
            ].map((stat, i) => (
              <div key={i} className="text-center">
                <p className="text-xs text-indigo-400 font-bold uppercase tracking-wider mb-1">{stat.label}</p>
                <p className="text-lg font-bold text-indigo-900">{stat.value}</p>
              </div>
            ))}
          </div>
        </div>

        <Menu />
        <Rooms />
        <PartyHall />
        <Gallery />
        
        {/* Visual Call to Action */}
        <section className="h-96 relative overflow-hidden flex items-center justify-center">
          <img 
            src="https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?auto=format&fit=crop&q=80&w=1600" 
            alt="Interior" 
            className="absolute inset-0 w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-indigo-900/60"></div>
          <div className="relative text-center px-4">
            <h3 className="text-3xl md:text-5xl font-bold text-white mb-6">Unforgettable Taste</h3>
            <p className="text-white/80 text-lg mb-8 max-w-lg mx-auto">Experience the best North Indian, South Indian, and Chinese flavors in a royal setting.</p>
          </div>
        </section>

        <Contact />
      </main>
      <Footer />
    </div>
  );
}

export default App;
