
import React from 'react';
import { Phone, MapPin, Mail, Clock } from 'lucide-react';

const Contact: React.FC = () => {
  return (
    <section id="contact" className="py-24 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-indigo-900 text-4xl font-bold mb-4">Connect With Us</h2>
          <div className="w-24 h-1 bg-orange-500 mx-auto rounded-full"></div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Info Cards */}
          <div className="lg:col-span-1 space-y-6">
            <div className="bg-gray-50 p-8 rounded-3xl border border-gray-100 flex items-start gap-5">
              <div className="bg-orange-100 p-3 rounded-2xl text-orange-600">
                <Phone size={24} />
              </div>
              <div>
                <h4 className="font-bold text-indigo-900 mb-2">Phone Numbers</h4>
                <p className="text-gray-600 mb-1">General: 9258696052</p>
                <p className="text-gray-600 mb-1">Reception: 05960297492</p>
                <p className="text-gray-600">Rooms: 8791224355</p>
              </div>
            </div>

            <div className="bg-gray-50 p-8 rounded-3xl border border-gray-100 flex items-start gap-5">
              <div className="bg-indigo-100 p-3 rounded-2xl text-indigo-600">
                <MapPin size={24} />
              </div>
              <div>
                <h4 className="font-bold text-indigo-900 mb-2">Our Location</h4>
                <p className="text-gray-600">Shyam Vihar, Bilari Road, Shahabad, Uttar Pradesh</p>
              </div>
            </div>

            <div className="bg-gray-50 p-8 rounded-3xl border border-gray-100 flex items-start gap-5">
              <div className="bg-green-100 p-3 rounded-2xl text-green-600">
                <Clock size={24} />
              </div>
              <div>
                <h4 className="font-bold text-indigo-900 mb-2">Operating Hours</h4>
                <p className="text-gray-600">Restaurant: 7:00 AM - 11:00 PM</p>
                <p className="text-gray-600">Hotel Check-in: 24/7</p>
              </div>
            </div>
          </div>

          {/* Map Placeholder logic */}
          <div className="lg:col-span-2 relative rounded-3xl overflow-hidden shadow-inner bg-gray-200 h-[500px] lg:h-full">
            <div className="absolute inset-0 flex items-center justify-center p-8 text-center">
              <div className="max-w-md">
                <MapPin size={64} className="mx-auto text-indigo-900/30 mb-6" />
                <h3 className="text-2xl font-bold text-indigo-900 mb-4">Find us in Shahabad</h3>
                <p className="text-gray-600 mb-8">Located conveniently on Bilari Road, Seven Seas is the perfect landmark for fine dining and comfortable stays.</p>
                <a 
                  href="https://www.google.com/maps/search/Seven+Seas+Hotel+Shahabad+Bilari+Road" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="inline-block bg-indigo-900 text-white px-8 py-3 rounded-xl font-bold"
                >
                  Open in Google Maps
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
