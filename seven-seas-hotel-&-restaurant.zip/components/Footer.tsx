
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-indigo-950 text-white py-12">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center gap-8 mb-12">
          <div className="text-center md:text-left">
            <span className="text-3xl font-bold tracking-tight">
              SE<span className="text-orange-500">VEN</span> SEAS
            </span>
            <p className="text-indigo-300 mt-2">Hotel & Restaurant | 100% Vegetarian</p>
          </div>
          
          <div className="flex gap-8 text-sm font-medium text-indigo-200">
            <a href="#menu" className="hover:text-white transition-colors">Menu</a>
            <a href="#rooms" className="hover:text-white transition-colors">Rooms</a>
            <a href="#hall" className="hover:text-white transition-colors">Party Hall</a>
            <a href="#contact" className="hover:text-white transition-colors">Location</a>
          </div>
        </div>
        
        <div className="pt-8 border-t border-indigo-900 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-indigo-400">
          <p>© {new Date().getFullYear()} Seven Seas Hotel & Restaurant. All Rights Reserved.</p>
          <p>Shyam Vihar, Bilari Road, Shahabad</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
