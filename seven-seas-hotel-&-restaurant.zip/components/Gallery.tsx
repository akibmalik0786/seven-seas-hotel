
import React, { useState } from 'react';
import { X, Maximize2, Camera } from 'lucide-react';

const Gallery: React.FC = () => {
  const [selectedImg, setSelectedImg] = useState<string | null>(null);

  const images = [
    { url: "https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&q=80&w=800", title: "Grand Banquet Hall" },
    { url: "https://images.unsplash.com/photo-1631049307264-da0ec9d70304?auto=format&fit=crop&q=80&w=800", title: "Premium AC Room" },
    { url: "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&q=80&w=800", title: "Authentic Dosa" },
    { url: "https://images.unsplash.com/photo-1505236858219-8359eb29e329?auto=format&fit=crop&q=80&w=800", title: "Wedding Setup" },
    { url: "https://images.unsplash.com/photo-1585937421612-70a008356fbe?auto=format&fit=crop&q=80&w=800", title: "Paneer Specialties" },
    { url: "https://images.unsplash.com/photo-1564501049412-61c2a3083791?auto=format&fit=crop&q=80&w=800", title: "Hotel Front View" },
  ];

  return (
    <section id="gallery" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-16">
          <div className="flex justify-center items-center gap-3 mb-4">
            <Camera className="text-orange-500" size={32} />
            <h2 className="text-indigo-900 text-4xl md:text-5xl font-black italic">Visual Journey</h2>
          </div>
          <div className="w-24 h-1.5 bg-orange-500 mx-auto rounded-full mb-6"></div>
          <p className="text-gray-600 font-medium max-w-lg mx-auto">Explore the luxury, comfort, and taste of Seven Seas through our lens.</p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 md:gap-8">
          {images.map((img, idx) => (
            <div 
              key={idx} 
              className="relative group overflow-hidden rounded-[2.5rem] cursor-pointer aspect-square shadow-xl border border-gray-50"
              onClick={() => setSelectedImg(img.url)}
            >
              <img 
                src={img.url} 
                alt={img.title} 
                className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-indigo-900/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-[1px]">
                <div className="text-white text-center p-4 transform translate-y-4 group-hover:translate-y-0 transition-all duration-500">
                  <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-3 backdrop-blur-md border border-white/30">
                    <Maximize2 size={20} className="text-white" />
                  </div>
                  <p className="font-black text-base uppercase tracking-widest">{img.title}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Lightbox */}
      {selectedImg && (
        <div className="fixed inset-0 z-[100] bg-indigo-950/95 flex items-center justify-center p-4 md:p-12" onClick={() => setSelectedImg(null)}>
          <button 
            className="absolute top-8 right-8 text-white hover:text-orange-500 transition-colors bg-white/10 p-3 rounded-2xl backdrop-blur-md border border-white/20"
          >
            <X size={32} />
          </button>
          <img 
            src={selectedImg} 
            className="max-w-full max-h-full object-contain rounded-[2rem] shadow-2xl animate-in fade-in zoom-in duration-300 border-4 border-white/10"
            alt="Gallery Preview"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </section>
  );
};

export default Gallery;
