
import React from 'react';
import { ChevronRight, MapPin } from 'lucide-react';

const Hero: React.FC = () => {
  const scrollTo = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const offset = 80;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;
      window.scrollTo({ top: offsetPosition, behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="relative h-screen flex items-center justify-center overflow-hidden bg-indigo-950">
      <div className="absolute inset-0 z-0">
        {/* Using a more reliable vertical facade image that matches the building's style */}
        <img 
          src="https://images.unsplash.com/photo-1445019980597-93fa8acb246c?auto=format&fit=crop&q=80&w=1920" 
          alt="Seven Seas Hotel Facade" 
          className="w-full h-full object-cover brightness-[0.3] scale-105 transition-opacity duration-700"
          onLoad={(e) => (e.currentTarget.style.opacity = '1')}
          style={{ opacity: 0 }}
        />
        {/* Vibrant purple/indigo gradient overlay to match the building glass */}
        <div className="absolute inset-0 bg-gradient-to-b from-indigo-950/60 via-indigo-900/40 to-indigo-950/80"></div>
      </div>
      
      <div className="relative z-10 text-center px-4 sm:px-6 mt-16">
        <div className="animate-in fade-in slide-in-from-bottom-8 duration-700">
          {/* Enhanced High-Visibility Badge */}
          <div className="inline-flex items-center gap-2 bg-orange-600 text-white px-8 py-3 rounded-full mb-10 shadow-[0_0_30px_rgba(234,88,12,0.4)] border border-orange-400/50 transform hover:scale-105 transition-transform cursor-default">
            <MapPin size={20} className="text-white fill-white/20 animate-bounce" />
            <span className="text-sm md:text-base font-black tracking-widest uppercase">
              Best 100% Veg Hotel in <span className="text-white border-b-2 border-white/60 ml-1">SHAHABAD</span>
            </span>
          </div>
          
          <h1 className="text-white text-6xl md:text-[10rem] font-black mb-6 drop-shadow-[0_10px_10px_rgba(0,0,0,0.5)] leading-[0.8] italic">
            SEVEN SEAS<br/>
            <span className="text-indigo-200 not-italic font-bold text-3xl md:text-6xl tracking-tighter block mt-4 drop-shadow-lg">HOTEL & RESTAURANT</span>
          </h1>
          
          <p className="text-gray-100 text-lg md:text-2xl max-w-3xl mx-auto mb-14 font-medium leading-relaxed drop-shadow-md">
            The heart of Shahabad's premium hospitality. Experience luxury AC rooms and world-class vegetarian dining.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
            <button 
              onClick={() => scrollTo('menu')}
              className="w-full sm:w-auto px-14 py-6 bg-orange-600 hover:bg-orange-500 text-white rounded-[2rem] font-black text-xl transition-all transform hover:scale-105 flex items-center justify-center gap-2 shadow-2xl shadow-orange-600/40"
            >
              Explore Menu <ChevronRight size={28} />
            </button>
            <button 
              onClick={() => scrollTo('rooms')}
              className="w-full sm:w-auto px-14 py-6 bg-white/10 hover:bg-white/20 backdrop-blur-2xl text-white border-2 border-white/40 rounded-[2rem] font-black text-xl transition-all transform hover:scale-105 shadow-2xl"
            >
              Book Your Stay
            </button>
          </div>
        </div>
      </div>
      
      {/* Scroll Indicator */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce opacity-60">
        <div className="w-1 h-12 rounded-full bg-gradient-to-b from-orange-500 to-transparent"></div>
      </div>
    </section>
  );
};

export default Hero;
