
import React, { useState } from 'react';
import { menuData } from '../data/menuData';

const Menu: React.FC = () => {
  const [activeTab, setActiveTab] = useState(menuData[0].title);

  // High-quality imagery mapping for each category to represent the menu visually
  const categoryImages: Record<string, string> = {
    "All Day Breakfast": "https://images.unsplash.com/photo-1571091718767-18b5b1457add?auto=format&fit=crop&q=80&w=600",
    "South Indian & Dosa": "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&q=80&w=600",
    "Indian Main Course": "https://images.unsplash.com/photo-1585937421612-70a008356fbe?auto=format&fit=crop&q=80&w=600",
    "Breads & More": "https://images.unsplash.com/photo-1633945274405-b6c8069047b0?auto=format&fit=crop&q=80&w=600",
    "Chinese & Pizza": "https://images.unsplash.com/photo-1585032226651-759b368d7246?auto=format&fit=crop&q=80&w=600",
    "Snacks & Tandoor": "https://images.unsplash.com/photo-1626074353765-517a681e40be?auto=format&fit=crop&q=80&w=600",
    "Rice & Thali": "https://images.unsplash.com/photo-1546833998-877b37c2e5c6?auto=format&fit=crop&q=80&w=600",
    "Beverages & Sweets": "https://images.unsplash.com/photo-1563805042-7684c019e1cb?auto=format&fit=crop&q=80&w=600"
  };

  const renderPrice = (price: any) => {
    if (typeof price === 'string' || typeof price === 'number') {
      return <span className="text-indigo-900 font-extrabold text-sm">₹{price}</span>;
    }
    if (Array.isArray(price)) {
      return (
        <div className="flex flex-wrap gap-2 text-xs">
          {price.map((v, i) => (
            <span key={i} className="bg-orange-50 px-2 py-1 rounded-md border border-orange-100">
              <span className="text-gray-500 font-medium uppercase mr-1">{v.label}:</span>
              <b className="text-indigo-900">₹{v.value}</b>
            </span>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <section id="menu" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-indigo-900 text-4xl md:text-5xl font-bold mb-4">Seven Seas Royal Menu</h2>
          <div className="w-24 h-1 bg-orange-500 mx-auto rounded-full mb-6"></div>
          <p className="text-gray-600 font-medium">100% Pure Vegetarian Delicacies | Freshly Prepared</p>
        </div>

        {/* Tabs - Now more scrollable on mobile */}
        <div className="flex overflow-x-auto pb-4 md:flex-wrap md:justify-center gap-3 mb-12 no-scrollbar">
          {menuData.map((cat) => (
            <button
              key={cat.title}
              onClick={() => setActiveTab(cat.title)}
              className={`whitespace-nowrap px-6 py-3 rounded-2xl text-sm font-bold transition-all duration-300 ${
                activeTab === cat.title 
                ? 'bg-orange-500 text-white shadow-lg scale-105' 
                : 'bg-white text-gray-600 hover:bg-orange-50 border border-gray-200 shadow-sm'
              }`}
            >
              {cat.title}
            </button>
          ))}
        </div>

        {/* Selected Category Header Image */}
        <div className="relative h-48 md:h-64 rounded-[2rem] overflow-hidden mb-12 shadow-xl border-4 border-white">
          <img 
            src={categoryImages[activeTab]} 
            className="w-full h-full object-cover brightness-75 transition-transform duration-1000 scale-105"
            alt={activeTab}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-indigo-900/60 flex items-end p-8">
            <h3 className="text-3xl md:text-4xl font-black text-white">{activeTab}</h3>
          </div>
        </div>

        {/* Menu Items Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {menuData.find(c => c.title === activeTab)?.items.map((item, idx) => (
            <div key={idx} className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 flex items-center justify-between group hover:shadow-md hover:border-orange-100 transition-all">
              <div className="flex-1 pr-4">
                <h4 className="text-gray-800 font-bold group-hover:text-indigo-900 transition-colors mb-1">{item.name}</h4>
                <div className="flex items-center gap-2">
                   {renderPrice(item.price)}
                </div>
              </div>
              <div className="w-1.5 h-8 bg-indigo-50 rounded-full group-hover:bg-orange-500 transition-colors"></div>
            </div>
          ))}
        </div>
        
        <div className="mt-20 p-8 md:p-16 rounded-[4rem] bg-indigo-900 text-white relative overflow-hidden text-center">
           <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2"></div>
           <div className="relative z-10 max-w-2xl mx-auto">
             <h4 className="text-3xl md:text-5xl font-black mb-6 italic leading-tight">Authentic Taste. Premium Quality.</h4>
             <p className="text-indigo-200 text-lg mb-10">We use only the finest ingredients and authentic spices to bring you the best vegetarian dining experience in Shahabad.</p>
             <div className="flex flex-col sm:flex-row gap-4 justify-center">
               <a href="tel:9258696052" className="bg-orange-500 text-white px-10 py-5 rounded-2xl font-black text-lg hover:bg-orange-600 transition-all transform hover:-translate-y-1 shadow-2xl shadow-orange-500/30">
                 Order Now: 9258696052
               </a>
             </div>
           </div>
        </div>
      </div>
    </section>
  );
};

export default Menu;
