
import React from 'react';
import { Users, Music, Utensils, Sparkles, Lightbulb, Snowflake } from 'lucide-react';

const PartyHall: React.FC = () => {
  return (
    <section id="hall" className="py-24 bg-indigo-950 text-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div className="order-2 lg:order-1 animate-in slide-in-from-left-12 duration-700">
            <div className="relative rounded-[3rem] overflow-hidden shadow-2xl border-4 border-white/5 group">
              {/* Replaced the woman photo with a grand banquet hall interior matching the user's facility style */}
              <img 
                src="https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&q=80&w=1200" 
                alt="Seven Seas Grand Party Hall Interior" 
                className="w-full aspect-[4/3] object-cover group-hover:scale-105 transition-transform duration-1000" 
              />
              <div className="absolute inset-0 bg-gradient-to-t from-indigo-950/90 via-transparent to-transparent"></div>
              <div className="absolute bottom-10 left-10">
                <div className="flex items-center gap-2 text-orange-400 font-black mb-2 tracking-[0.3em] uppercase text-xs">
                  <Sparkles size={14} />
                  Luxury Venue
                </div>
                <h3 className="text-4xl font-black italic">The Grand Hall</h3>
              </div>
            </div>
          </div>
          
          <div className="order-1 lg:order-2">
            <h2 className="text-4xl md:text-7xl font-black mb-8 leading-tight italic">Celebrate In <br/><span className="text-orange-500">Royal Style</span></h2>
            <p className="text-indigo-200 text-lg mb-12 leading-relaxed font-medium">
              Host your dream wedding, birthday, or corporate event in our magnificent party hall. Featuring high ceilings, majestic chandeliers, and premium white sofa seating, we ensure your special day looks truly royal.
            </p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-12">
              {[
                { icon: <Users className="text-orange-500" />, title: "350+ Capacity", desc: "Spacious for grand events" },
                { icon: <Lightbulb className="text-orange-500" />, title: "Royal Chandeliers", desc: "Warm & golden ambiance" },
                { icon: <Snowflake className="text-orange-500" />, title: "Powerful AC", desc: "Stay cool in peak summer" },
                { icon: <Utensils className="text-orange-500" />, title: "Premium Catering", desc: "Signature 100% Veg thali" }
              ].map((item, i) => (
                <div key={i} className="flex gap-4 p-6 rounded-[2rem] bg-white/5 border border-white/10 hover:bg-white/10 transition-all group">
                  <div className="mt-1 group-hover:scale-110 transition-transform">{item.icon}</div>
                  <div>
                    <h4 className="font-bold text-white text-lg mb-1">{item.title}</h4>
                    <p className="text-indigo-300 text-sm font-medium">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <a href="tel:9258696052" className="inline-flex justify-center items-center bg-orange-500 hover:bg-orange-600 text-white px-12 py-5 rounded-3xl font-black text-lg transition-all transform hover:scale-105 shadow-2xl shadow-orange-500/30">
                Book Hall Today
              </a>
              <div className="flex items-center gap-3 px-6 py-4 rounded-3xl bg-indigo-900/50 border border-indigo-800">
                <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                <span className="text-sm font-bold text-indigo-100">Booking Open for 2024-25</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PartyHall;
