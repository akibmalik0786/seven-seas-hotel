
import React from 'react';
import { Wifi, Wind, Coffee, Tv, ShieldCheck } from 'lucide-react';

const Rooms: React.FC = () => {
  const rooms = [
    {
      type: "Deluxe Premium Room",
      // Using a placeholder that matches the provided photo: Modern room with bed and sofa seating
      image: "https://images.unsplash.com/photo-1631049307264-da0ec9d70304?auto=format&fit=crop&q=80&w=1200",
      features: ["King Size Comfort Bed", "Twin Sofa Seating Area", "LED TV & Entertainment", "Large Window with Curtains", "Full Air Conditioning"],
      price: "Best Price on Request",
      tag: "Best Seller"
    },
    {
      type: "Executive AC Suite",
      image: "https://images.unsplash.com/photo-1591088398332-8a7791972843?auto=format&fit=crop&q=80&w=1200",
      features: ["Extra Spacious Layout", "Dedicated Workspace", "Premium Toiletries", "High Speed WiFi", "24/7 Room Service"],
      price: "Best Price on Request",
      tag: "Luxury"
    }
  ];

  return (
    <section id="rooms" className="py-24 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="animate-in fade-in slide-in-from-left-8 duration-700">
            <h2 className="text-indigo-900 text-4xl md:text-5xl font-bold mb-4 italic">Stay with Us</h2>
            <div className="w-24 h-1.5 bg-orange-500 rounded-full mb-6"></div>
            <p className="text-gray-600 max-w-xl text-lg">
              Experience the comfort of home in our well-appointed, clean, and air-conditioned rooms. 
              Each room is designed for a peaceful stay in the heart of Shahabad.
            </p>
          </div>
          <div className="flex flex-col gap-3">
            <a href="tel:8791224355" className="px-8 py-4 bg-indigo-900 text-white rounded-2xl font-bold hover:bg-indigo-800 transition-all shadow-xl shadow-indigo-100 text-center">
              Call Room Manager
            </a>
            <div className="flex items-center gap-2 text-green-600 font-semibold justify-center md:justify-end text-sm">
              <ShieldCheck size={18} />
              100% Safe & Clean
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {rooms.map((room, idx) => (
            <div key={idx} className="group overflow-hidden rounded-[2.5rem] bg-white border border-gray-100 shadow-2xl hover:shadow-indigo-100 transition-all duration-500">
              <div className="relative h-80 overflow-hidden">
                <img 
                  src={room.image} 
                  alt={room.type} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" 
                />
                <div className="absolute top-6 left-6 flex gap-2">
                  <span className="bg-orange-500 text-white px-4 py-1.5 rounded-full text-xs font-black uppercase tracking-widest shadow-lg">
                    {room.tag}
                  </span>
                  <span className="bg-white/90 backdrop-blur-sm text-indigo-900 px-4 py-1.5 rounded-full text-xs font-bold shadow-lg">
                    AC ROOM
                  </span>
                </div>
              </div>
              <div className="p-10">
                <div className="flex justify-between items-start mb-6">
                  <h3 className="text-3xl font-bold text-indigo-900 leading-tight">{room.type}</h3>
                  <div className="text-right">
                    <p className="text-xs text-gray-400 font-bold uppercase mb-1">Pricing</p>
                    <span className="font-black text-xl text-orange-600">{room.price}</span>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-3 gap-x-6 mb-10">
                  {room.features.map((f, i) => (
                    <div key={i} className="flex items-center gap-3 text-gray-600 font-medium group/feat">
                      <div className="w-1.5 h-1.5 bg-orange-400 rounded-full group-hover/feat:scale-150 transition-transform"></div>
                      {f}
                    </div>
                  ))}
                </div>
                
                <div className="flex items-center justify-between border-t pt-8 border-gray-50">
                  <div className="flex gap-5 text-gray-300">
                    <Wifi size={24} className="hover:text-indigo-400 transition-colors" />
                    <Wind size={24} className="hover:text-indigo-400 transition-colors" />
                    <Coffee size={24} className="hover:text-indigo-400 transition-colors" />
                    <Tv size={24} className="hover:text-indigo-400 transition-colors" />
                  </div>
                  <button className="text-indigo-600 font-bold hover:text-orange-500 transition-colors flex items-center gap-2 group/btn">
                    View Details
                    <div className="w-8 h-8 rounded-full bg-indigo-50 flex items-center justify-center group-hover/btn:bg-orange-500 group-hover/btn:text-white transition-all">
                      →
                    </div>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Rooms;
