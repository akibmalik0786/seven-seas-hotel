
export interface PriceVariant {
  label: string;
  value: number;
}

export interface MenuItem {
  name: string;
  price: string | number | PriceVariant[];
  description?: string;
}

export interface MenuCategory {
  title: string;
  items: MenuItem[];
}

export interface RoomDetail {
  type: string;
  features: string[];
  image: string;
  price: string;
}
